 <!DOCTYPE html>
<html lang="pl">

<head>
  <title>Rośliny domowe</title>
  <link rel="icon" type="image/x-icon" href="/images/favicon.ico">
</head>


<meta charset="utf-8">
     <title>Moja witryna</title>

     <meta name="description" content="Opis zawartości strony dla wyszukiwarek">
     <meta name="keywords" content="słowa, kluczowe, opisujące, zawartość">

     <meta http-equiv="X-Ua-Compatible" content="IE=edge,chrome=1">
     <link rel="stylesheet" href="arkusz.css">
     <script src="skrypt.js"></script>


 

<meta charset="UTF-8">
<style> 
#example1 {
  background-image: url(marmur.jpg);
  background-position: left corner;
  background-repeat: repeat;
  padding: 15px;
}
</style>

<style>
.p1 {
  font-family: Lucida Handwriting, Cursive;
}
</style>

<style>
body {margin:10px;}

div.polaroid {
  width: 20%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
}

div.container {
  text-align: center;
  padding: 10px 10px;
}
</style>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
  background-color: #009966;
  padding: 20px;
  text-align: center;
  
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #009966; 
  background-image: linear-gradient(#009966, white);
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three unequal columns that floats next to each other */
.column {
  float: left;
  padding: 10px;
  
}

/* Left and right column */
.column.side {
  width: 15%;
  background-color: #ddd;
  
}

/* Middle column */
.column.middle {
  width: 70%;
  height: 100%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
  height: 100%
}

.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
  margin-top: 20px;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column.side, .column.middle {
    width: 100%;
  }
}

</style>
<style>
.tooltip {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;

  /* Position the tooltip */
  position: absolute;
  z-index: 1;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}
</style>
<body style="text-align:center;">


</style>
<body>
<div class="header" >
  <p style="font-size:48px">

</p>
<h1 class="p1" style= "color:white; font-size:48px; font-size:300%; " > &#127807; Rośliny domowe &#127807;</h1>
</header>



<div class="topnav" style="font-family:courier; font-size:130%;">
<a href="link" class="button"></a>
<a href="link" class="button"></button>
<a href="link" class="button"></a>
<a href="link" class="button"></a>

</div>

<div class="row">
  <div class="column side"><h2 style="font-family:courier; font-size:130%;" >Odwiedź nas</h2>
    <p> <li style="font-family:courier; font-size:130%;">Instagram</a></li>
    <a href="https://www.instagram.com/explore/tags/kwiaty/"><img src="https://cdn-icons-png.flaticon.com/512/25/25425.png?w=360.jpg" style="width:100px;height:100px;"></a>
    <li style="font-family:courier; font-size:130%;">Facebook</a></li>
    <a href="https://pl-pl.facebook.com/KochamyKwiaty/"><img src="https://cdn-icons-png.flaticon.com/512/44/44646.png" style="width:100px;height:100px;"></p></a>
  </div>

<div class="column middle">
<div id="example1">

<center><h3 style="color:#009966; font-size:200%; "><b>Kontakt</b></h3>
<?php include "kontakt/kontakt.php";?>







<div class="tooltip" style="font-family:courier; font-size:130%;" >Opowiedz nam o swojej roślinie!
  <span class="tooltiptext">Wyślij do nas maila!</span>
</div>
</div>
</div>

<div class="row">
  <div class="column side"><h2 style="font-family:courier; font-size:130%;" ></h2>
    
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.vertical-menu {
  width: 100%;
}

.vertical-menu a {
  background-color: #eee;
  color: black;
  display: block;
  padding: 12px;
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>


<div class="vertical-menu">
  <a href="index.html" class="active">Home</a>
  <a href="zdjeecia.html">Zdjęcia</a>
  <a href="waszerosliny.html">Wasze rośliny</a>
  <a href="kontakt1.html">Kontakt</a>
  <a href="quizz/inne.html">Inne</a>
</div>

</body>
</html>
  </div>

<div class="footer">
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:hover {background-color: #009966;}
</style>
</head>
<body>



<table>
  <tr>
    <th>Nazwa rośliny</th>
    <th>Stanowisko</th>
    <th>Pielęgnacja</th>
  </tr>
  <tr>
    <td>Skrzydłokwiat</td>
    <td>Półcień</td>
    <td>Mało wody</td>
  </tr>
  <tr>
    <td>Storczyk</td>
    <td>Słoneczne</td>
    <td>Dużo wody</td>
  </tr>
  <tr>
    <td>Paproć</td>
    <td>Półcień</td>
    <td>Dużo wody</td>
  </tr>
</table>
</div>


</div>
</body>
</html>